kanalet_outside = {
    type = "region",
    condition_basic = (bridge and break_bush and feather) or (plains and open_kanalet and break_bush),
    condition_glitched = glitched and wasteland and feather and bracelet
  }