# LASR Tracker Pack for Poptracker

This is a Link's Awakening Switch Remake map tracker package for Poptracker.

## Installation

- Install [Poptracker](https://github.com/black-sliver/PopTracker/releases/latest) onto the computer that youd like to use the tracker application on.
- Download the latest release from the [releases section](https://github.com/Br00ty/lasr_brooty/releases/latest), and then move it into your `/poptracker/packs/` folder.
- Launch `Poptracker` and select the `Link's Awakening (Switch)` pack variant you'd like to use.
- You're all set!


## More Info

Want to be part of the Poptracker community and/or have questions? Check out the ['Unofficial' PopTracker Discord Server](https://discord.com/invite/gwThqMCPgK)!

## License

If you're going to copy this pack, please at least fork it and credit. thank you. 